# muzkat tutorial #

## serial communication ##

#### libs
- rxtx

you can download the latest version of the lib here: 

- http://rxtx.qbang.org/
- http://rxtx.qbang.org/wiki/index.php/Download